function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  //
}